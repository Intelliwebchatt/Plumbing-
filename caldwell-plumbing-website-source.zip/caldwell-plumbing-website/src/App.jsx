import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import HomePage from './components/HomePage'
import AboutPage from './components/AboutPage'
import ServicesPage from './components/ServicesPage'
import WaterHeaterPage from './components/WaterHeaterPage'
import DrainSewerPage from './components/DrainSewerPage'
import PlumbingRepairsPage from './components/PlumbingRepairsPage'
import ServiceAreasPage from './components/ServiceAreasPage'
import ContactPage from './components/ContactPage'
import FAQPage from './components/FAQPage'
import './App.css'

function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/services/water-heater" element={<WaterHeaterPage />} />
            <Route path="/services/drain-sewer" element={<DrainSewerPage />} />
            <Route path="/services/plumbing-repairs" element={<PlumbingRepairsPage />} />
            <Route path="/service-areas" element={<ServiceAreasPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/faq" element={<FAQPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  )
}

export default App

