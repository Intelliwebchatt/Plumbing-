import React from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { 
  Settings, 
  Camera, 
  Zap, 
  Shield, 
  Clock, 
  CheckCircle,
  Phone,
  AlertTriangle,
  Wrench,
  Search
} from 'lucide-react'
import { Link } from 'react-router-dom'

const DrainSewerPage = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-caldwell-navy text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Drain & Sewer Services in Prattville & Millbrook
            </h1>
            <p className="text-xl text-gray-200 mb-8">
              Professional drain cleaning, camera inspections, and sewer line repair using the latest technology and proven techniques.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-caldwell-orange hover:bg-caldwell-orange/90 text-white px-8 py-4 text-lg"
                asChild
              >
                <Link to="/contact">Schedule Service</Link>
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-caldwell-navy px-8 py-4 text-lg"
                asChild
              >
                <a href="tel:3343656107">Emergency Service</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-caldwell-navy mb-4">
              Complete Drain & Sewer Solutions
            </h2>
            <p className="text-xl text-caldwell-gray max-w-3xl mx-auto">
              From simple drain clogs to complex sewer line issues, we have the tools and expertise to solve your drainage problems efficiently.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Drain Cleaning */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Settings className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-caldwell-navy mb-4">Professional Drain Cleaning</h3>
                <p className="text-caldwell-gray mb-6">
                  High-powered drain cleaning equipment to clear even the toughest clogs and restore proper flow.
                </p>
                <ul className="text-sm text-caldwell-gray text-left space-y-2">
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Kitchen sink drains</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Bathroom drains</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Floor drains</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Main sewer lines</li>
                </ul>
              </CardContent>
            </Card>

            {/* Camera Inspection */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Camera className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-caldwell-navy mb-4">Video Camera Inspection</h3>
                <p className="text-caldwell-gray mb-6">
                  Advanced camera technology to accurately diagnose drain and sewer line problems without guesswork.
                </p>
                <ul className="text-sm text-caldwell-gray text-left space-y-2">
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Locate blockages precisely</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Identify pipe damage</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Root intrusion detection</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Pre-purchase inspections</li>
                </ul>
              </CardContent>
            </Card>

            {/* Sewer Line Repair */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Wrench className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-caldwell-navy mb-4">Sewer Line Repair & Replacement</h3>
                <p className="text-caldwell-gray mb-6">
                  Expert repair and replacement of damaged sewer lines using modern techniques and quality materials.
                </p>
                <ul className="text-sm text-caldwell-gray text-left space-y-2">
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Trenchless repair options</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Traditional excavation</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Pipe lining services</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Root removal</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Common Drain Problems */}
      <section className="py-16 bg-caldwell-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-caldwell-navy mb-4">
              Common Drain & Sewer Problems We Solve
            </h2>
            <p className="text-xl text-caldwell-gray max-w-3xl mx-auto">
              Don't let drainage issues disrupt your daily routine. We quickly diagnose and resolve all types of drain and sewer problems.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Residential Problems */}
            <div>
              <h3 className="text-2xl font-bold text-caldwell-navy mb-6">Residential Drain Issues</h3>
              <div className="space-y-4">
                <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                  <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-1">Slow-Draining Sinks</h4>
                    <p className="text-caldwell-gray text-sm">Grease buildup, food particles, or soap scum causing partial blockages</p>
                  </div>
                </div>
                
                <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                  <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-1">Clogged Shower Drains</h4>
                    <p className="text-caldwell-gray text-sm">Hair, soap residue, and mineral deposits blocking water flow</p>
                  </div>
                </div>
                
                <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                  <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-1">Toilet Backups</h4>
                    <p className="text-caldwell-gray text-sm">Main line blockages causing sewage backup into fixtures</p>
                  </div>
                </div>
                
                <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                  <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-1">Recurring Clogs</h4>
                    <p className="text-caldwell-gray text-sm">Persistent blockages that return shortly after clearing</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Sewer Line Problems */}
            <div>
              <h3 className="text-2xl font-bold text-caldwell-navy mb-6">Sewer Line Problems</h3>
              <div className="space-y-4">
                <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                  <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-1">Tree Root Intrusion</h4>
                    <p className="text-caldwell-gray text-sm">Roots growing into sewer lines causing blockages and damage</p>
                  </div>
                </div>
                
                <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                  <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-1">Broken or Collapsed Pipes</h4>
                    <p className="text-caldwell-gray text-sm">Age, ground shifting, or external pressure causing pipe failure</p>
                  </div>
                </div>
                
                <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                  <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-1">Sewer Gas Odors</h4>
                    <p className="text-caldwell-gray text-sm">Damaged pipes or dry traps allowing sewer gases to enter your home</p>
                  </div>
                </div>
                
                <div className="flex items-start p-4 bg-white rounded-lg border border-gray-200">
                  <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-1">Multiple Drain Backups</h4>
                    <p className="text-caldwell-gray text-sm">Main sewer line blockage affecting multiple fixtures simultaneously</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Process */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-caldwell-navy mb-4">
              Our Proven Drain & Sewer Service Process
            </h2>
            <p className="text-xl text-caldwell-gray max-w-3xl mx-auto">
              We follow a systematic approach to ensure accurate diagnosis and effective solutions for all your drainage problems.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-caldwell-navy text-white p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Search className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-caldwell-navy mb-2">1. Inspection</h3>
              <p className="text-caldwell-gray">Thorough assessment of your drainage system to identify the root cause of the problem.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-caldwell-navy text-white p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Camera className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-caldwell-navy mb-2">2. Diagnosis</h3>
              <p className="text-caldwell-gray">Video camera inspection when needed to pinpoint exact location and nature of blockages.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-caldwell-navy text-white p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Settings className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-caldwell-navy mb-2">3. Solution</h3>
              <p className="text-caldwell-gray">Professional cleaning or repair using the most appropriate tools and techniques for your situation.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-caldwell-navy text-white p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Shield className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-caldwell-navy mb-2">4. Prevention</h3>
              <p className="text-caldwell-gray">Recommendations for ongoing maintenance to prevent future drainage problems.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Service */}
      <section className="py-16 bg-caldwell-orange text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Emergency Drain & Sewer Service Available
            </h2>
            <p className="text-xl mb-8">
              Sewer backups and major drain clogs can't wait. We provide emergency service to get your plumbing system working again quickly.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
              <div className="text-center">
                <Clock className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">Same-Day Service</h3>
                <p>Emergency calls answered promptly with same-day service availability.</p>
              </div>
              
              <div className="text-center">
                <Zap className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">Fast Response</h3>
                <p>Rapid response to minimize damage and restore normal operation.</p>
              </div>
              
              <div className="text-center">
                <Shield className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">Professional Equipment</h3>
                <p>Advanced tools and equipment to handle any emergency situation.</p>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-caldwell-orange hover:bg-gray-100 px-8 py-4 text-lg"
                asChild
              >
                <Link to="/contact">Schedule Service</Link>
              </Button>
              <div className="flex items-center justify-center">
                <Phone className="w-6 h-6 mr-2" />
                <a href="tel:3343656107" className="text-2xl font-bold hover:underline">
                  (334) 365-6107
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default DrainSewerPage

