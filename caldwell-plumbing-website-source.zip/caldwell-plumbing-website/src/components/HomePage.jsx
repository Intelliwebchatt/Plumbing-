import React from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { 
  Phone, 
  Clock, 
  Shield, 
  Award, 
  DollarSign, 
  Wrench, 
  Droplets, 
  Settings, 
  CheckCircle,
  Star,
  Users,
  Calendar,
  MapPin
} from 'lucide-react'

const HomePage = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section 
        className="relative bg-cover bg-center bg-no-repeat text-white py-20"
        style={{
          backgroundImage: "linear-gradient(rgba(10, 49, 97, 0.8), rgba(45, 139, 161, 0.8)), url('/hero-background.jpg')"
        }}
      >
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white drop-shadow-lg">
              Trusted Plumbing Solutions by Your Neighbors Since 1981
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-100 drop-shadow-md">
              State-certified plumbing professionals delivering quality workmanship, fair pricing, and lasting solutions for all your residential and commercial plumbing needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-4 text-lg shadow-lg"
                asChild
              >
                <Link to="/contact">Schedule Service</Link>
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-2 border-white text-white hover:bg-white hover:text-blue-900 px-8 py-4 text-lg shadow-lg"
                asChild
              >
                <a href="tel:3343656107">Emergency Service</a>
              </Button>
            </div>
            <div className="mt-8 flex items-center justify-center text-gray-200">
              <Phone className="w-5 h-5 mr-2" />
              <span className="text-lg">(334) 365-6107</span>
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
              Your Complete Plumbing & Drain Solution
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From routine maintenance to emergency repairs, we provide comprehensive plumbing services with the expertise and reliability you can trust.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Water Heater Services */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-teal-600 text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Droplets className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-blue-900 mb-4">Water Heater Services</h3>
                <p className="text-gray-600 mb-6">
                  Expert installation, repair, and maintenance of traditional and tankless water heaters. Same-day service available.
                </p>
                <Button variant="outline" className="border-teal-600 text-teal-600 hover:bg-teal-600 hover:text-white" asChild>
                  <Link to="/services/water-heater">Learn More</Link>
                </Button>
              </CardContent>
            </Card>

            {/* Drain & Sewer Services */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-teal-600 text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Settings className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-blue-900 mb-4">Drain & Sewer Services</h3>
                <p className="text-gray-600 mb-6">
                  Professional drain cleaning, camera inspections, and sewer line repair using the latest technology and techniques.
                </p>
                <Button variant="outline" className="border-teal-600 text-teal-600 hover:bg-teal-600 hover:text-white" asChild>
                  <Link to="/services/drain-sewer">Learn More</Link>
                </Button>
              </CardContent>
            </Card>

            {/* Plumbing Repairs */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-teal-600 text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Wrench className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-blue-900 mb-4">Plumbing Repairs</h3>
                <p className="text-gray-600 mb-6">
                  From leaky faucets to pipe replacements, we handle all residential and commercial plumbing repairs with precision.
                </p>
                <Button variant="outline" className="border-teal-600 text-teal-600 hover:bg-teal-600 hover:text-white" asChild>
                  <Link to="/services/plumbing-repairs">Learn More</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Problem/Solution Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Problems We Solve */}
            <div>
              <h2 className="text-3xl font-bold text-blue-900 mb-6">
                The Plumbing Problems We Solve
              </h2>
              <div className="space-y-4">
                <div className="flex items-start">
                  <CheckCircle className="w-6 h-6 text-teal-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-blue-900">Emergency Plumbing Situations</h4>
                    <p className="text-gray-600">Burst pipes, sewer backups, and water heater failures that need immediate attention.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="w-6 h-6 text-teal-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-blue-900">Persistent Drain Issues</h4>
                    <p className="text-gray-600">Slow drains, recurring clogs, and mysterious odors that keep coming back.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="w-6 h-6 text-teal-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-blue-900">Aging Plumbing Systems</h4>
                    <p className="text-gray-600">Old pipes, outdated fixtures, and inefficient water heaters that need upgrading.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="w-6 h-6 text-teal-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-blue-900">High Water Bills</h4>
                    <p className="text-gray-600">Hidden leaks and inefficient systems that are costing you money every month.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* The Caldwell Difference */}
            <div>
              <h2 className="text-3xl font-bold text-blue-900 mb-6">
                The Caldwell & Sons Difference
              </h2>
              <div className="space-y-4">
                <div className="flex items-start">
                  <Shield className="w-6 h-6 text-orange-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-blue-900">Honest, Upfront Pricing</h4>
                    <p className="text-gray-600">No hidden fees or surprise charges. You'll know the cost before we start any work.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Users className="w-6 h-6 text-orange-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-blue-900">Local Family Business</h4>
                    <p className="text-gray-600">We live and work in your community. Your satisfaction is our reputation.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Award className="w-6 h-6 text-orange-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-blue-900">40+ Years Experience</h4>
                    <p className="text-gray-600">Four decades of solving plumbing problems with skill and professionalism.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Clock className="w-6 h-6 text-orange-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-blue-900">Emergency Service Available</h4>
                    <p className="text-gray-600">When plumbing emergencies strike, we're here to help, even on weekends.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
              Why Prattville & Millbrook Homeowners Choose Caldwell & Sons
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-blue-900 text-white p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Award className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-blue-900 mb-2">40+ Years Experience</h3>
              <p className="text-gray-600">Serving Alabama families since 1981 with trusted expertise.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-900 text-white p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Shield className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-blue-900 mb-2">Licensed & Insured</h3>
              <p className="text-gray-600">State certified and fully insured for your peace of mind.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-900 text-white p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <DollarSign className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-blue-900 mb-2">Fair Transparent Pricing</h3>
              <p className="text-gray-600">Honest estimates with no hidden fees or surprises.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-900 text-white p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <CheckCircle className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-blue-900 mb-2">ALAGASCO Rebate Partner</h3>
              <p className="text-gray-600">Help you save money with energy-efficient upgrades.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-blue-900 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              What Our Customers Say
            </h2>
            <div className="flex items-center justify-center mb-4">
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-6 h-6 fill-current" />
                ))}
              </div>
              <span className="ml-2 text-lg">4.9/5 Average Rating</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-white text-blue-900">
              <CardContent className="p-6">
                <div className="flex text-yellow-400 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <p className="mb-4">
                  "Caldwell & Sons saved the day when our water heater failed on a Sunday morning. They came out the same day and had us back up and running quickly. Professional and fair pricing!"
                </p>
                <div className="font-semibold">Sarah M.</div>
                <div className="text-gray-600 text-sm">Prattville, AL</div>
              </CardContent>
            </Card>
            
            <Card className="bg-white text-blue-900">
              <CardContent className="p-6">
                <div className="flex text-yellow-400 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <p className="mb-4">
                  "We've used Caldwell & Sons for years. They're honest, reliable, and always do quality work. It's rare to find a business you can trust completely these days."
                </p>
                <div className="font-semibold">Mike R.</div>
                <div className="text-gray-600 text-sm">Millbrook, AL</div>
              </CardContent>
            </Card>
            
            <Card className="bg-white text-blue-900">
              <CardContent className="p-6">
                <div className="flex text-yellow-400 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <p className="mb-4">
                  "Excellent service from start to finish. They explained everything clearly, worked efficiently, and cleaned up after themselves. Highly recommend!"
                </p>
                <div className="font-semibold">Jennifer L.</div>
                <div className="text-gray-600 text-sm">Deatsville, AL</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 bg-orange-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready for Professional Plumbing Service?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Don't let plumbing problems disrupt your day. Contact Caldwell & Sons for reliable, professional service you can trust.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-orange-600 hover:bg-gray-100 px-8 py-4 text-lg"
              asChild
            >
              <Link to="/contact">Schedule Service Today</Link>
            </Button>
            <div className="flex items-center justify-center">
              <Phone className="w-6 h-6 mr-2" />
              <a href="tel:3343656107" className="text-2xl font-bold hover:underline">
                (334) 365-6107
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default HomePage

