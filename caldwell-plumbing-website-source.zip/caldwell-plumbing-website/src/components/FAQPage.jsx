import React, { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { 
  ChevronDown, 
  ChevronUp, 
  Phone, 
  HelpCircle,
  Clock,
  DollarSign,
  Shield,
  Wrench
} from 'lucide-react'
import { Link } from 'react-router-dom'

const FAQPage = () => {
  const [openItems, setOpenItems] = useState(new Set())

  const toggleItem = (index) => {
    const newOpenItems = new Set(openItems)
    if (newOpenItems.has(index)) {
      newOpenItems.delete(index)
    } else {
      newOpenItems.add(index)
    }
    setOpenItems(newOpenItems)
  }

  const faqCategories = [
    {
      title: "General Service Questions",
      icon: <HelpCircle className="w-6 h-6" />,
      questions: [
        {
          question: "What areas do you serve?",
          answer: "We proudly serve Prattville, Millbrook, Deatsville, and the surrounding Autauga County area. We've been serving these communities since 1981 and know the local plumbing challenges well."
        },
        {
          question: "Do you offer emergency plumbing services?",
          answer: "Yes! We provide emergency plumbing services for urgent situations like burst pipes, sewer backups, and water heater failures. Emergency service is available on weekends and after hours. Call (334) 365-6107 for immediate assistance."
        },
        {
          question: "How quickly can you respond to service calls?",
          answer: "For routine service calls, we typically schedule within 1-2 business days. For urgent issues, we offer same-day service when possible. Emergency calls receive immediate attention with rapid response times."
        },
        {
          question: "Are you licensed and insured?",
          answer: "Absolutely. Caldwell & Sons is a state-certified, licensed, and fully insured plumbing contractor. We maintain all required licenses and comprehensive liability insurance for your protection and peace of mind."
        }
      ]
    },
    {
      title: "Pricing & Payment",
      icon: <DollarSign className="w-6 h-6" />,
      questions: [
        {
          question: "Do you provide free estimates?",
          answer: "Yes, we provide free estimates for most plumbing projects. For service calls, there is a diagnostic fee that is applied toward the cost of repairs if you choose to proceed with our services."
        },
        {
          question: "What forms of payment do you accept?",
          answer: "We accept cash, checks, and all major credit cards for your convenience. Payment is due upon completion of work unless other arrangements have been made in advance."
        },
        {
          question: "Do you offer any warranties on your work?",
          answer: "Yes, we stand behind our work with warranties on both labor and parts. Warranty terms vary depending on the type of service performed. We'll explain all warranty coverage before beginning any work."
        },
        {
          question: "Are there any hidden fees in your pricing?",
          answer: "Never. We believe in transparent, upfront pricing. You'll know the cost before we start any work, and there are no hidden fees or surprise charges. What we quote is what you pay."
        }
      ]
    },
    {
      title: "Water Heater Services",
      icon: <Wrench className="w-6 h-6" />,
      questions: [
        {
          question: "How long do water heaters typically last?",
          answer: "Traditional tank water heaters typically last 8-12 years, while tankless units can last 15-20 years with proper maintenance. Factors like water quality, usage patterns, and maintenance frequency affect lifespan."
        },
        {
          question: "Should I repair or replace my water heater?",
          answer: "This depends on the age of your unit, the cost of repairs, and energy efficiency considerations. Generally, if repair costs exceed 50% of replacement cost, or if your unit is over 10 years old, replacement is often the better investment."
        },
        {
          question: "What size water heater do I need?",
          answer: "Water heater sizing depends on your household size, usage patterns, and peak demand. We'll assess your specific needs and recommend the appropriate size to ensure adequate hot water without oversizing."
        },
        {
          question: "Do you install tankless water heaters?",
          answer: "Yes, we install both traditional tank and tankless water heaters. Tankless units provide endless hot water and are more energy-efficient, though they have higher upfront costs. We'll help you determine which type best fits your needs and budget."
        }
      ]
    },
    {
      title: "Drain & Sewer Services",
      icon: <Shield className="w-6 h-6" />,
      questions: [
        {
          question: "What causes recurring drain clogs?",
          answer: "Recurring clogs often indicate deeper issues like tree root intrusion, pipe damage, or improper pipe slope. We use video camera inspection to identify the root cause and provide lasting solutions rather than temporary fixes."
        },
        {
          question: "How often should I have my drains cleaned?",
          answer: "For preventive maintenance, we recommend professional drain cleaning annually for most homes. Homes with heavy usage, older pipes, or recurring issues may benefit from more frequent cleaning."
        },
        {
          question: "Can you clear main sewer line blockages?",
          answer: "Yes, we have professional equipment to clear main sewer line blockages, including high-powered drain machines and hydro-jetting equipment. We also offer video camera inspection to locate and diagnose sewer line problems."
        },
        {
          question: "What should I do if I have a sewer backup?",
          answer: "Stop using all water fixtures immediately and call us for emergency service at (334) 365-6107. Avoid contact with sewage water and don't attempt to clear the blockage yourself, as this can worsen the problem."
        }
      ]
    },
    {
      title: "Maintenance & Prevention",
      icon: <Clock className="w-6 h-6" />,
      questions: [
        {
          question: "How can I prevent plumbing problems?",
          answer: "Regular maintenance is key: avoid putting grease down drains, don't flush non-biodegradable items, have annual water heater maintenance, and address small issues before they become major problems. We offer preventive maintenance services to help."
        },
        {
          question: "What should I do if I have a plumbing emergency?",
          answer: "First, shut off the main water supply if there's flooding. For gas water heaters, turn off the gas supply if you smell gas. Then call us immediately at (334) 365-6107. Don't attempt major repairs yourself."
        },
        {
          question: "How do I shut off my main water supply?",
          answer: "The main water shutoff is typically located near where the water line enters your home, often near the water meter. It may be a lever-style valve or require a water meter key. We can show you during a service visit."
        },
        {
          question: "Should I attempt DIY plumbing repairs?",
          answer: "Simple tasks like unclogging a toilet or replacing a faucet aerator are generally safe for homeowners. However, anything involving gas lines, main water lines, or major installations should be left to licensed professionals to ensure safety and code compliance."
        }
      ]
    }
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-caldwell-teal text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-gray-200 mb-8">
              Get answers to common plumbing questions from our experienced professionals. Don't see your question? Give us a call!
            </p>
            <div className="flex items-center justify-center text-gray-200">
              <Phone className="w-6 h-6 mr-2" />
              <a href="tel:3343656107" className="text-2xl font-bold hover:text-white transition-colors">
                (334) 365-6107
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {faqCategories.map((category, categoryIndex) => (
              <div key={categoryIndex} className="mb-12">
                <div className="flex items-center mb-6">
                  <div className="bg-caldwell-navy text-white p-3 rounded-lg mr-4">
                    {category.icon}
                  </div>
                  <h2 className="text-2xl md:text-3xl font-bold text-caldwell-navy">
                    {category.title}
                  </h2>
                </div>
                
                <div className="space-y-4">
                  {category.questions.map((faq, questionIndex) => {
                    const itemIndex = `${categoryIndex}-${questionIndex}`
                    const isOpen = openItems.has(itemIndex)
                    
                    return (
                      <Card key={questionIndex} className="border border-gray-200 hover:border-caldwell-teal transition-colors">
                        <CardContent className="p-0">
                          <button
                            onClick={() => toggleItem(itemIndex)}
                            className="w-full p-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
                          >
                            <h3 className="text-lg font-semibold text-caldwell-navy pr-4">
                              {faq.question}
                            </h3>
                            {isOpen ? (
                              <ChevronUp className="w-5 h-5 text-caldwell-teal flex-shrink-0" />
                            ) : (
                              <ChevronDown className="w-5 h-5 text-caldwell-gray flex-shrink-0" />
                            )}
                          </button>
                          
                          {isOpen && (
                            <div className="px-6 pb-6">
                              <p className="text-caldwell-gray leading-relaxed">
                                {faq.answer}
                              </p>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Still Have Questions */}
      <section className="py-16 bg-caldwell-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-caldwell-navy mb-6">
              Still Have Questions?
            </h2>
            <p className="text-xl text-caldwell-gray mb-8">
              Our experienced plumbing professionals are here to help. Contact us for personalized answers to your specific plumbing concerns.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="border-2 border-caldwell-teal">
                <CardContent className="p-8 text-center">
                  <Phone className="w-12 h-12 text-caldwell-teal mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-caldwell-navy mb-4">Call Us Directly</h3>
                  <p className="text-caldwell-gray mb-6">
                    Speak with our knowledgeable team for immediate answers to your plumbing questions.
                  </p>
                  <Button 
                    className="bg-caldwell-teal hover:bg-caldwell-navy text-white"
                    asChild
                  >
                    <a href="tel:3343656107">Call (334) 365-6107</a>
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-2 border-caldwell-orange">
                <CardContent className="p-8 text-center">
                  <HelpCircle className="w-12 h-12 text-caldwell-orange mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-caldwell-navy mb-4">Schedule a Consultation</h3>
                  <p className="text-caldwell-gray mb-6">
                    Get a professional assessment and detailed answers during a service visit.
                  </p>
                  <Button 
                    className="bg-caldwell-orange hover:bg-caldwell-navy text-white"
                    asChild
                  >
                    <Link to="/contact">Schedule Service</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Notice */}
      <section className="py-16 bg-caldwell-orange text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Plumbing Emergency?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Don't wait when you have a plumbing emergency. Our experienced team is available for same-day emergency service.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-caldwell-orange hover:bg-gray-100 px-8 py-4 text-lg"
              asChild
            >
              <Link to="/contact">Schedule Service</Link>
            </Button>
            <div className="flex items-center justify-center">
              <Phone className="w-6 h-6 mr-2" />
              <a href="tel:3343656107" className="text-2xl font-bold hover:underline">
                (334) 365-6107
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default FAQPage

