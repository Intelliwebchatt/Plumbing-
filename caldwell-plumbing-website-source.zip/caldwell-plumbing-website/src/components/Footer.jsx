import React from 'react'
import { Link } from 'react-router-dom'
import { Phone, MapPin, Clock, Mail, Wrench } from 'lucide-react'

const Footer = () => {
  return (
    <footer className="bg-caldwell-navy text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-caldwell-teal text-white p-2 rounded-lg">
                <Wrench className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Caldwell & Sons</h3>
                <p className="text-caldwell-teal text-sm font-medium">PLUMBING & DRAIN</p>
              </div>
            </div>
            <p className="text-gray-300 mb-4">
              Family-owned plumbing company serving Prattville, Millbrook, and surrounding Alabama communities since 1981.
            </p>
            <div className="flex items-center text-caldwell-teal mb-2">
              <Phone className="w-4 h-4 mr-2" />
              <a href="tel:3343656107" className="hover:text-white transition-colors">
                (334) 365-6107
              </a>
            </div>
            <div className="flex items-center text-gray-300">
              <Clock className="w-4 h-4 mr-2" />
              <span>Monday - Friday: 8 AM - 5 PM</span>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Our Services</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/services/water-heater" className="text-gray-300 hover:text-caldwell-teal transition-colors">
                  Water Heater Services
                </Link>
              </li>
              <li>
                <Link to="/services/drain-sewer" className="text-gray-300 hover:text-caldwell-teal transition-colors">
                  Drain & Sewer Services
                </Link>
              </li>
              <li>
                <Link to="/services/plumbing-repairs" className="text-gray-300 hover:text-caldwell-teal transition-colors">
                  Plumbing Repairs
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-caldwell-teal transition-colors">
                  Emergency Service
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-300 hover:text-caldwell-teal transition-colors">
                  All Services
                </Link>
              </li>
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Service Areas</h4>
            <ul className="space-y-2">
              <li className="flex items-center text-gray-300">
                <MapPin className="w-4 h-4 mr-2 text-caldwell-teal" />
                Prattville, AL
              </li>
              <li className="flex items-center text-gray-300">
                <MapPin className="w-4 h-4 mr-2 text-caldwell-teal" />
                Millbrook, AL
              </li>
              <li className="flex items-center text-gray-300">
                <MapPin className="w-4 h-4 mr-2 text-caldwell-teal" />
                Deatsville, AL
              </li>
              <li className="flex items-center text-gray-300">
                <MapPin className="w-4 h-4 mr-2 text-caldwell-teal" />
                Autauga County
              </li>
            </ul>
            <Link 
              to="/service-areas" 
              className="inline-block mt-3 text-caldwell-teal hover:text-white transition-colors"
            >
              View All Areas →
            </Link>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/about" className="text-gray-300 hover:text-caldwell-teal transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-300 hover:text-caldwell-teal transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-caldwell-teal transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <a href="tel:3343656107" className="text-caldwell-orange hover:text-white transition-colors font-medium">
                  Emergency Service
                </a>
              </li>
            </ul>

            {/* Certifications */}
            <div className="mt-6">
              <h5 className="text-sm font-semibold mb-2">Certifications</h5>
              <ul className="text-xs text-gray-400 space-y-1">
                <li>Licensed & Insured</li>
                <li>State Certified</li>
                <li>ALAGASCO Approved</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="text-gray-400 text-sm mb-4 md:mb-0">
            © 2025 Caldwell & Sons Plumbing & Drain. All rights reserved.
          </div>
          <div className="text-gray-400 text-sm">
            Serving Alabama families since 1981
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

