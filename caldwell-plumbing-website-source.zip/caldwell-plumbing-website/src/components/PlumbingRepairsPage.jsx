import React from 'react'

const PlumbingRepairsPage = () => {
  return (
    <div className="min-h-screen py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-caldwell-navy mb-8">Plumbing Repairs</h1>
        <p className="text-lg text-caldwell-gray">Plumbing repairs page content coming soon...</p>
      </div>
    </div>
  )
}

export default PlumbingRepairsPage

