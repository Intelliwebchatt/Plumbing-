import React, { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Phone, Menu, X, Wrench, Droplets, Settings, MapPin } from 'lucide-react'

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isServicesOpen, setIsServicesOpen] = useState(false)
  const location = useLocation()

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen)
  const closeMenu = () => setIsMenuOpen(false)

  const isActive = (path) => location.pathname === path

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      {/* Utility Bar */}
      <div className="bg-caldwell-navy text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center space-x-4">
            <span>Monday - Friday: 8 AM - 5 PM</span>
            <span className="hidden md:inline">Emergency Service Available</span>
          </div>
          <div className="flex items-center space-x-4">
            <a href="tel:3343656107" className="flex items-center hover:text-caldwell-teal transition-colors">
              <Phone className="w-4 h-4 mr-1" />
              (334) 365-6107
            </a>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3" onClick={closeMenu}>
            <div className="bg-caldwell-navy text-white p-3 rounded-lg">
              <Wrench className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-caldwell-navy">Caldwell & Sons</h1>
              <p className="text-caldwell-teal text-sm font-medium">PLUMBING & DRAIN</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <Link 
              to="/" 
              className={`font-medium transition-colors hover:text-caldwell-teal ${
                isActive('/') ? 'text-caldwell-teal' : 'text-caldwell-navy'
              }`}
            >
              Home
            </Link>
            <Link 
              to="/about" 
              className={`font-medium transition-colors hover:text-caldwell-teal ${
                isActive('/about') ? 'text-caldwell-teal' : 'text-caldwell-navy'
              }`}
            >
              About Us
            </Link>
            
            {/* Services Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setIsServicesOpen(true)}
              onMouseLeave={() => setIsServicesOpen(false)}
            >
              <button className="font-medium text-caldwell-navy hover:text-caldwell-teal transition-colors flex items-center">
                Services
                <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              
              {isServicesOpen && (
                <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-lg shadow-xl border border-gray-200 py-2 z-50">
                  <Link 
                    to="/services" 
                    className="block px-4 py-2 text-caldwell-navy hover:bg-caldwell-white hover:text-caldwell-teal transition-colors"
                  >
                    All Services
                  </Link>
                  <Link 
                    to="/services/water-heater" 
                    className="flex items-center px-4 py-2 text-caldwell-navy hover:bg-caldwell-white hover:text-caldwell-teal transition-colors"
                  >
                    <Droplets className="w-4 h-4 mr-2 text-caldwell-teal" />
                    Water Heater Services
                  </Link>
                  <Link 
                    to="/services/drain-sewer" 
                    className="flex items-center px-4 py-2 text-caldwell-navy hover:bg-caldwell-white hover:text-caldwell-teal transition-colors"
                  >
                    <Settings className="w-4 h-4 mr-2 text-caldwell-teal" />
                    Drain & Sewer Services
                  </Link>
                  <Link 
                    to="/services/plumbing-repairs" 
                    className="flex items-center px-4 py-2 text-caldwell-navy hover:bg-caldwell-white hover:text-caldwell-teal transition-colors"
                  >
                    <Wrench className="w-4 h-4 mr-2 text-caldwell-teal" />
                    Plumbing Repairs
                  </Link>
                </div>
              )}
            </div>

            <Link 
              to="/service-areas" 
              className={`font-medium transition-colors hover:text-caldwell-teal ${
                isActive('/service-areas') ? 'text-caldwell-teal' : 'text-caldwell-navy'
              }`}
            >
              Service Areas
            </Link>
            <Link 
              to="/faq" 
              className={`font-medium transition-colors hover:text-caldwell-teal ${
                isActive('/faq') ? 'text-caldwell-teal' : 'text-caldwell-navy'
              }`}
            >
              FAQ
            </Link>
            <Link 
              to="/contact" 
              className={`font-medium transition-colors hover:text-caldwell-teal ${
                isActive('/contact') ? 'text-caldwell-teal' : 'text-caldwell-navy'
              }`}
            >
              Contact
            </Link>
          </nav>

          {/* CTA Buttons */}
          <div className="hidden lg:flex items-center space-x-3">
            <Button 
              variant="outline" 
              className="border-caldwell-navy text-caldwell-navy hover:bg-caldwell-navy hover:text-white"
              asChild
            >
              <Link to="/contact">Schedule Service</Link>
            </Button>
            <Button 
              className="bg-caldwell-orange hover:bg-caldwell-orange/90 text-white"
              asChild
            >
              <a href="tel:3343656107">Emergency Service</a>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="lg:hidden p-2 text-caldwell-navy"
            onClick={toggleMenu}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden mt-4 pb-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-4 pt-4">
              <Link 
                to="/" 
                className="font-medium text-caldwell-navy hover:text-caldwell-teal transition-colors"
                onClick={closeMenu}
              >
                Home
              </Link>
              <Link 
                to="/about" 
                className="font-medium text-caldwell-navy hover:text-caldwell-teal transition-colors"
                onClick={closeMenu}
              >
                About Us
              </Link>
              <Link 
                to="/services" 
                className="font-medium text-caldwell-navy hover:text-caldwell-teal transition-colors"
                onClick={closeMenu}
              >
                Services
              </Link>
              <Link 
                to="/services/water-heater" 
                className="font-medium text-caldwell-gray hover:text-caldwell-teal transition-colors pl-4"
                onClick={closeMenu}
              >
                Water Heater Services
              </Link>
              <Link 
                to="/services/drain-sewer" 
                className="font-medium text-caldwell-gray hover:text-caldwell-teal transition-colors pl-4"
                onClick={closeMenu}
              >
                Drain & Sewer Services
              </Link>
              <Link 
                to="/services/plumbing-repairs" 
                className="font-medium text-caldwell-gray hover:text-caldwell-teal transition-colors pl-4"
                onClick={closeMenu}
              >
                Plumbing Repairs
              </Link>
              <Link 
                to="/service-areas" 
                className="font-medium text-caldwell-navy hover:text-caldwell-teal transition-colors"
                onClick={closeMenu}
              >
                Service Areas
              </Link>
              <Link 
                to="/faq" 
                className="font-medium text-caldwell-navy hover:text-caldwell-teal transition-colors"
                onClick={closeMenu}
              >
                FAQ
              </Link>
              <Link 
                to="/contact" 
                className="font-medium text-caldwell-navy hover:text-caldwell-teal transition-colors"
                onClick={closeMenu}
              >
                Contact
              </Link>
              
              {/* Mobile CTA Buttons */}
              <div className="flex flex-col space-y-2 pt-4">
                <Button 
                  variant="outline" 
                  className="border-caldwell-navy text-caldwell-navy hover:bg-caldwell-navy hover:text-white w-full"
                  asChild
                  onClick={closeMenu}
                >
                  <Link to="/contact">Schedule Service</Link>
                </Button>
                <Button 
                  className="bg-caldwell-orange hover:bg-caldwell-orange/90 text-white w-full"
                  asChild
                  onClick={closeMenu}
                >
                  <a href="tel:3343656107">Emergency Service</a>
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}

export default Header

