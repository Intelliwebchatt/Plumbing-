import React, { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { 
  Phone, 
  MapPin, 
  Clock, 
  Mail,
  Calendar,
  Wrench,
  Droplets,
  Settings,
  AlertTriangle
} from 'lucide-react'

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    serviceType: '',
    urgency: '',
    description: '',
    preferredTime: ''
  })

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // In a real implementation, this would send the form data to a server
    console.log('Form submitted:', formData)
    alert('Thank you for your message! We will contact you soon.')
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-caldwell-navy text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Contact Caldwell & Sons Plumbing & Drain
            </h1>
            <p className="text-xl text-gray-200 mb-8">
              Ready to schedule service or have questions about your plumbing needs? We're here to help with professional, reliable service.
            </p>
            <div className="flex items-center justify-center text-gray-200">
              <Phone className="w-6 h-6 mr-2" />
              <a href="tel:3343656107" className="text-2xl font-bold hover:text-caldwell-teal transition-colors">
                (334) 365-6107
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Information & Form */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div>
              <h2 className="text-3xl font-bold text-caldwell-navy mb-8">Get in Touch</h2>
              
              {/* Contact Cards */}
              <div className="space-y-6">
                <Card className="border-l-4 border-l-caldwell-teal">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <Phone className="w-6 h-6 text-caldwell-teal mr-3" />
                      <h3 className="text-xl font-bold text-caldwell-navy">Phone</h3>
                    </div>
                    <p className="text-caldwell-gray mb-2">Call us for immediate assistance:</p>
                    <a href="tel:3343656107" className="text-2xl font-bold text-caldwell-navy hover:text-caldwell-teal transition-colors">
                      (334) 365-6107
                    </a>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-caldwell-teal">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <Clock className="w-6 h-6 text-caldwell-teal mr-3" />
                      <h3 className="text-xl font-bold text-caldwell-navy">Business Hours</h3>
                    </div>
                    <div className="space-y-2 text-caldwell-gray">
                      <p><strong>Monday - Friday:</strong> 8:00 AM - 5:00 PM</p>
                      <p><strong>Saturday & Sunday:</strong> Emergency Service Only</p>
                      <p className="text-caldwell-orange font-semibold">Emergency service available 24/7</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-caldwell-teal">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <MapPin className="w-6 h-6 text-caldwell-teal mr-3" />
                      <h3 className="text-xl font-bold text-caldwell-navy">Service Areas</h3>
                    </div>
                    <div className="text-caldwell-gray">
                      <p className="mb-2">Proudly serving:</p>
                      <ul className="space-y-1">
                        <li>• Prattville, AL</li>
                        <li>• Millbrook, AL</li>
                        <li>• Deatsville, AL</li>
                        <li>• Autauga County</li>
                        <li>• Surrounding areas</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Emergency Notice */}
              <Card className="mt-6 bg-caldwell-orange text-white">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <AlertTriangle className="w-6 h-6 mr-3" />
                    <h3 className="text-xl font-bold">Emergency Service</h3>
                  </div>
                  <p className="mb-4">
                    Experiencing a plumbing emergency? Don't wait - call us immediately for same-day service.
                  </p>
                  <Button 
                    className="bg-white text-caldwell-orange hover:bg-gray-100"
                    asChild
                  >
                    <a href="tel:3343656107">Call Emergency Line</a>
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Contact Form */}
            <div>
              <h2 className="text-3xl font-bold text-caldwell-navy mb-8">Schedule Service</h2>
              
              <Card>
                <CardContent className="p-8">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Personal Information */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-caldwell-navy mb-2">
                          Full Name *
                        </label>
                        <Input
                          id="name"
                          name="name"
                          type="text"
                          required
                          value={formData.name}
                          onChange={handleInputChange}
                          className="border-caldwell-gray focus:border-caldwell-teal"
                        />
                      </div>
                      <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-caldwell-navy mb-2">
                          Phone Number *
                        </label>
                        <Input
                          id="phone"
                          name="phone"
                          type="tel"
                          required
                          value={formData.phone}
                          onChange={handleInputChange}
                          className="border-caldwell-gray focus:border-caldwell-teal"
                        />
                      </div>
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-caldwell-navy mb-2">
                        Email Address
                      </label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="border-caldwell-gray focus:border-caldwell-teal"
                      />
                    </div>

                    <div>
                      <label htmlFor="address" className="block text-sm font-medium text-caldwell-navy mb-2">
                        Service Address *
                      </label>
                      <Input
                        id="address"
                        name="address"
                        type="text"
                        required
                        value={formData.address}
                        onChange={handleInputChange}
                        placeholder="Street address, city, state, zip"
                        className="border-caldwell-gray focus:border-caldwell-teal"
                      />
                    </div>

                    {/* Service Details */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="serviceType" className="block text-sm font-medium text-caldwell-navy mb-2">
                          Service Type *
                        </label>
                        <select
                          id="serviceType"
                          name="serviceType"
                          required
                          value={formData.serviceType}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-caldwell-gray rounded-md focus:border-caldwell-teal focus:outline-none"
                        >
                          <option value="">Select a service</option>
                          <option value="water-heater">Water Heater Service</option>
                          <option value="drain-cleaning">Drain Cleaning</option>
                          <option value="sewer-repair">Sewer Line Repair</option>
                          <option value="plumbing-repair">General Plumbing Repair</option>
                          <option value="leak-repair">Leak Repair</option>
                          <option value="installation">New Installation</option>
                          <option value="maintenance">Preventive Maintenance</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                      <div>
                        <label htmlFor="urgency" className="block text-sm font-medium text-caldwell-navy mb-2">
                          Urgency Level *
                        </label>
                        <select
                          id="urgency"
                          name="urgency"
                          required
                          value={formData.urgency}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-caldwell-gray rounded-md focus:border-caldwell-teal focus:outline-none"
                        >
                          <option value="">Select urgency</option>
                          <option value="emergency">Emergency (Same Day)</option>
                          <option value="urgent">Urgent (Within 24 hours)</option>
                          <option value="soon">Soon (Within a few days)</option>
                          <option value="routine">Routine (Within a week)</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label htmlFor="preferredTime" className="block text-sm font-medium text-caldwell-navy mb-2">
                        Preferred Time
                      </label>
                      <select
                        id="preferredTime"
                        name="preferredTime"
                        value={formData.preferredTime}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-caldwell-gray rounded-md focus:border-caldwell-teal focus:outline-none"
                      >
                        <option value="">No preference</option>
                        <option value="morning">Morning (8 AM - 12 PM)</option>
                        <option value="afternoon">Afternoon (12 PM - 5 PM)</option>
                        <option value="weekend">Weekend</option>
                      </select>
                    </div>

                    <div>
                      <label htmlFor="description" className="block text-sm font-medium text-caldwell-navy mb-2">
                        Problem Description *
                      </label>
                      <Textarea
                        id="description"
                        name="description"
                        required
                        value={formData.description}
                        onChange={handleInputChange}
                        placeholder="Please describe the plumbing issue you're experiencing..."
                        rows={4}
                        className="border-caldwell-gray focus:border-caldwell-teal"
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-caldwell-navy hover:bg-caldwell-teal text-white py-3 text-lg"
                    >
                      Submit Service Request
                    </Button>

                    <p className="text-sm text-caldwell-gray text-center">
                      * Required fields. We'll contact you within 2 hours during business hours.
                    </p>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Service Icons */}
      <section className="py-16 bg-caldwell-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-caldwell-navy mb-4">
              What Can We Help You With Today?
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-caldwell-teal text-white p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <Droplets className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-bold text-caldwell-navy mb-2">Water Heater Issues</h3>
              <p className="text-caldwell-gray">No hot water, leaks, or strange noises from your water heater</p>
            </div>
            
            <div className="text-center">
              <div className="bg-caldwell-teal text-white p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <Settings className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-bold text-caldwell-navy mb-2">Drain Problems</h3>
              <p className="text-caldwell-gray">Slow drains, clogs, or sewer backups affecting your home</p>
            </div>
            
            <div className="text-center">
              <div className="bg-caldwell-teal text-white p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <Wrench className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-bold text-caldwell-navy mb-2">General Repairs</h3>
              <p className="text-caldwell-gray">Leaky faucets, running toilets, or other plumbing repairs</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default ContactPage

