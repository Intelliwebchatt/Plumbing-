import React from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { 
  Droplets, 
  Thermometer, 
  Zap, 
  DollarSign, 
  Clock, 
  Shield,
  CheckCircle,
  Phone,
  Wrench,
  AlertTriangle
} from 'lucide-react'
import { Link } from 'react-router-dom'

const WaterHeaterPage = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-caldwell-teal text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Water Heater Services in Prattville & Millbrook
            </h1>
            <p className="text-xl text-gray-200 mb-8">
              Expert installation, repair, and maintenance of traditional and tankless water heaters. Same-day service available for emergencies.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-caldwell-orange hover:bg-caldwell-orange/90 text-white px-8 py-4 text-lg"
                asChild
              >
                <Link to="/contact">Schedule Service</Link>
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-caldwell-teal px-8 py-4 text-lg"
                asChild
              >
                <a href="tel:3343656107">Emergency Service</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-caldwell-navy mb-4">
              Complete Water Heater Solutions
            </h2>
            <p className="text-xl text-caldwell-gray max-w-3xl mx-auto">
              From emergency repairs to new installations, we handle all your water heater needs with expertise and efficiency.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Installation */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-caldwell-navy text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Wrench className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-caldwell-navy mb-4">Water Heater Installation</h3>
                <p className="text-caldwell-gray mb-6">
                  Professional installation of traditional tank and tankless water heaters with proper sizing and code compliance.
                </p>
                <ul className="text-sm text-caldwell-gray text-left space-y-2">
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Proper sizing consultation</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Code-compliant installation</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Warranty protection</li>
                </ul>
              </CardContent>
            </Card>

            {/* Repair */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-caldwell-navy text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Thermometer className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-caldwell-navy mb-4">Water Heater Repair</h3>
                <p className="text-caldwell-gray mb-6">
                  Fast, reliable repairs for all water heater brands and models. Same-day service available for emergencies.
                </p>
                <ul className="text-sm text-caldwell-gray text-left space-y-2">
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Same-day emergency service</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />All brands and models</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Upfront pricing</li>
                </ul>
              </CardContent>
            </Card>

            {/* Maintenance */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-caldwell-navy text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Shield className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-caldwell-navy mb-4">Preventive Maintenance</h3>
                <p className="text-caldwell-gray mb-6">
                  Regular maintenance to extend your water heater's life and prevent costly breakdowns.
                </p>
                <ul className="text-sm text-caldwell-gray text-left space-y-2">
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Annual inspections</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Tank flushing service</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-caldwell-teal mr-2" />Component replacement</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Traditional vs Tankless */}
      <section className="py-16 bg-caldwell-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-caldwell-navy mb-4">
              Traditional vs. Tankless Water Heaters
            </h2>
            <p className="text-xl text-caldwell-gray max-w-3xl mx-auto">
              We'll help you choose the right water heater for your home's needs, budget, and energy efficiency goals.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Traditional Water Heaters */}
            <Card className="border-2 border-caldwell-teal">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="bg-caldwell-teal text-white p-3 rounded-full mr-4">
                    <Droplets className="w-6 h-6" />
                  </div>
                  <h3 className="text-2xl font-bold text-caldwell-navy">Traditional Tank Water Heaters</h3>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-2">Best For:</h4>
                    <ul className="text-caldwell-gray space-y-1">
                      <li>• Homes with moderate hot water usage</li>
                      <li>• Budget-conscious installations</li>
                      <li>• Existing tank water heater replacements</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-2">Advantages:</h4>
                    <ul className="text-caldwell-gray space-y-1">
                      <li>• Lower upfront cost</li>
                      <li>• Familiar technology</li>
                      <li>• Easier installation</li>
                      <li>• Reliable hot water storage</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-2">Available Sizes:</h4>
                    <p className="text-caldwell-gray">30, 40, 50, 75, and 80-gallon capacities</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tankless Water Heaters */}
            <Card className="border-2 border-caldwell-orange">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="bg-caldwell-orange text-white p-3 rounded-full mr-4">
                    <Zap className="w-6 h-6" />
                  </div>
                  <h3 className="text-2xl font-bold text-caldwell-navy">Tankless Water Heaters</h3>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-2">Best For:</h4>
                    <ul className="text-caldwell-gray space-y-1">
                      <li>• High hot water demand homes</li>
                      <li>• Energy efficiency priorities</li>
                      <li>• Space-saving installations</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-2">Advantages:</h4>
                    <ul className="text-caldwell-gray space-y-1">
                      <li>• Endless hot water supply</li>
                      <li>• 20-30% more energy efficient</li>
                      <li>• Space-saving design</li>
                      <li>• Longer lifespan (20+ years)</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-caldwell-navy mb-2">ALAGASCO Rebates:</h4>
                    <p className="text-caldwell-gray">Qualify for utility rebates on energy-efficient models</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Common Problems */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-caldwell-navy mb-4">
              Common Water Heater Problems We Fix
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="flex items-start p-4 bg-gray-50 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-caldwell-navy mb-1">No Hot Water</h4>
                <p className="text-caldwell-gray text-sm">Heating element or gas valve issues</p>
              </div>
            </div>
            
            <div className="flex items-start p-4 bg-gray-50 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-caldwell-navy mb-1">Insufficient Hot Water</h4>
                <p className="text-caldwell-gray text-sm">Sediment buildup or undersized unit</p>
              </div>
            </div>
            
            <div className="flex items-start p-4 bg-gray-50 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-caldwell-navy mb-1">Water Leaks</h4>
                <p className="text-caldwell-gray text-sm">Tank corrosion or loose connections</p>
              </div>
            </div>
            
            <div className="flex items-start p-4 bg-gray-50 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-caldwell-navy mb-1">Strange Noises</h4>
                <p className="text-caldwell-gray text-sm">Sediment buildup or heating element issues</p>
              </div>
            </div>
            
            <div className="flex items-start p-4 bg-gray-50 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-caldwell-navy mb-1">Rusty Water</h4>
                <p className="text-caldwell-gray text-sm">Anode rod replacement needed</p>
              </div>
            </div>
            
            <div className="flex items-start p-4 bg-gray-50 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-caldwell-orange mr-3 mt-1 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-caldwell-navy mb-1">High Energy Bills</h4>
                <p className="text-caldwell-gray text-sm">Inefficient operation or old unit</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-caldwell-navy text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Why Choose Caldwell & Sons for Water Heater Service?
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Clock className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">Same-Day Service</h3>
              <p className="text-gray-300">Emergency water heater repairs available the same day you call.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <DollarSign className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">Upfront Pricing</h3>
              <p className="text-gray-300">Know the cost before we start work - no hidden fees or surprises.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Shield className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">Licensed & Insured</h3>
              <p className="text-gray-300">State certified plumbing contractor with full insurance coverage.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Droplets className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">40+ Years Experience</h3>
              <p className="text-gray-300">Four decades of water heater expertise serving Alabama families.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-caldwell-orange text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Need Water Heater Service Today?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Don't wait for a complete water heater failure. Contact Caldwell & Sons for professional service you can trust.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-caldwell-orange hover:bg-gray-100 px-8 py-4 text-lg"
              asChild
            >
              <Link to="/contact">Schedule Service</Link>
            </Button>
            <div className="flex items-center justify-center">
              <Phone className="w-6 h-6 mr-2" />
              <a href="tel:3343656107" className="text-2xl font-bold hover:underline">
                (334) 365-6107
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default WaterHeaterPage

