import React from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { 
  Shield, 
  Award, 
  Users, 
  Heart, 
  TrendingUp, 
  Home,
  CheckCircle,
  Phone
} from 'lucide-react'
import { Link } from 'react-router-dom'

const AboutPage = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-caldwell-navy text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              About Caldwell & Sons Plumbing & Drain
            </h1>
            <p className="text-xl text-gray-200 mb-8">
              Four decades of trusted plumbing expertise serving Alabama families and businesses with integrity, quality, and community commitment.
            </p>
          </div>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-caldwell-navy mb-8 text-center">
              Our Story: Four Decades of Service Excellence
            </h2>
            
            <div className="prose prose-lg max-w-none text-caldwell-gray">
              <p className="text-xl leading-relaxed mb-6">
                In 1981, Caldwell & Sons Plumbing was started in Prattville, Alabama, with a simple mission: to provide honest, reliable plumbing services to our neighbors and community. Over the years, we have built a reputation for being honest and committed to providing the best service possible at the best price.
              </p>
              
              <p className="text-lg leading-relaxed mb-6">
                What began as a small family operation has grown into one of the most trusted plumbing companies in central Alabama, but our core values remain unchanged. We believe that every customer deserves transparent pricing, quality workmanship, and the respect that comes from treating their home as if it were our own.
              </p>
              
              <p className="text-lg leading-relaxed mb-8">
                As a state certified, licensed & insured plumbing contractor, you can be assured that we are competent and professional. We provide both residential plumbing & drain needs as well as commercial projects. We also work with ALAGASCO incentive programs to help you save the most money possible.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-caldwell-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-caldwell-navy mb-4">
              Our Core Values
            </h2>
            <p className="text-xl text-caldwell-gray max-w-3xl mx-auto">
              These principles guide every interaction, every job, and every decision we make as your trusted plumbing professionals.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Integrity */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Shield className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-caldwell-navy mb-4">Integrity in Every Interaction</h3>
                <p className="text-caldwell-gray">
                  We believe in honest communication, transparent pricing, and doing what's right for our customers, even when no one is watching.
                </p>
              </CardContent>
            </Card>

            {/* Quality */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Award className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-caldwell-navy mb-4">Quality Without Compromise</h3>
                <p className="text-caldwell-gray">
                  Every job we complete meets our high standards for workmanship, using quality materials and proven techniques that stand the test of time.
                </p>
              </CardContent>
            </Card>

            {/* Community */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Users className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-caldwell-navy mb-4">Community Connection</h3>
                <p className="text-caldwell-gray">
                  As local residents, we're invested in our community's well-being and committed to building lasting relationships with our neighbors.
                </p>
              </CardContent>
            </Card>

            {/* Improvement */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <TrendingUp className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-caldwell-navy mb-4">Continuous Improvement</h3>
                <p className="text-caldwell-gray">
                  We stay current with industry best practices, new technologies, and continuing education to provide the most effective solutions.
                </p>
              </CardContent>
            </Card>

            {/* Respect */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Home className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-caldwell-navy mb-4">Respect for Your Home and Time</h3>
                <p className="text-caldwell-gray">
                  We treat your property with care, arrive on time, and work efficiently to minimize disruption to your daily routine.
                </p>
              </CardContent>
            </Card>

            {/* Service */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-caldwell-teal text-white p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Heart className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-caldwell-navy mb-4">Service Excellence</h3>
                <p className="text-caldwell-gray">
                  We go above and beyond to ensure every customer is completely satisfied with our work and their overall experience.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Certifications & Credentials */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-caldwell-navy mb-8 text-center">
              Certifications & Professional Credentials
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-2xl font-bold text-caldwell-navy mb-6">Professional Certifications</h3>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <CheckCircle className="w-6 h-6 text-caldwell-teal mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-caldwell-navy">State of Alabama Certified Plumbing Contractor</h4>
                      <p className="text-caldwell-gray">Licensed to perform all residential and commercial plumbing work in Alabama.</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="w-6 h-6 text-caldwell-teal mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-caldwell-navy">Fully Licensed and Insured</h4>
                      <p className="text-caldwell-gray">Comprehensive liability insurance and bonding for your protection and peace of mind.</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="w-6 h-6 text-caldwell-teal mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-caldwell-navy">ALAGASCO Approved Contractor</h4>
                      <p className="text-caldwell-gray">Authorized to install energy-efficient equipment that qualifies for utility rebates.</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-2xl font-bold text-caldwell-navy mb-6">Ongoing Education</h3>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <CheckCircle className="w-6 h-6 text-caldwell-teal mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-caldwell-navy">Continuing Education Requirements</h4>
                      <p className="text-caldwell-gray">Regular training to stay current with codes, regulations, and best practices.</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="w-6 h-6 text-caldwell-teal mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-caldwell-navy">Technology Training</h4>
                      <p className="text-caldwell-gray">Ongoing education on new plumbing technologies and energy-efficient solutions.</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="w-6 h-6 text-caldwell-teal mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-caldwell-navy">Safety Certification</h4>
                      <p className="text-caldwell-gray">Current safety training and certification to protect our team and your property.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-caldwell-navy text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Experience the Caldwell & Sons Difference
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto text-gray-200">
            Join thousands of satisfied customers who trust us for all their plumbing needs. Contact us today to experience professional service you can count on.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-caldwell-orange hover:bg-caldwell-orange/90 text-white px-8 py-4 text-lg"
              asChild
            >
              <Link to="/contact">Schedule Service</Link>
            </Button>
            <div className="flex items-center justify-center">
              <Phone className="w-6 h-6 mr-2" />
              <a href="tel:3343656107" className="text-2xl font-bold hover:underline">
                (334) 365-6107
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default AboutPage

